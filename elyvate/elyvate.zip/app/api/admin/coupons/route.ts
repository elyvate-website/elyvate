import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { isAdminAuthed } from '@/lib/adminAuth'

function unauthorized() {
  return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
}

// GET — list all coupons
export async function GET(req: NextRequest) {
  if (!isAdminAuthed(req)) return unauthorized()

  const db = supabaseAdmin()
  const { data, error } = await db
    .from('coupons')
    .select('*')
    .order('created_at', { ascending: false })

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}

// POST — create coupon
export async function POST(req: NextRequest) {
  if (!isAdminAuthed(req)) return unauthorized()

  try {
    const body = await req.json()
    const { code, type, value, min_order, usage_limit, expires_at, is_active } = body

    if (!code || !type || !value) {
      return NextResponse.json({ error: 'Code, type and value are required' }, { status: 400 })
    }
    if (!['percentage', 'fixed'].includes(type)) {
      return NextResponse.json({ error: 'Type must be percentage or fixed' }, { status: 400 })
    }
    if (type === 'percentage' && (value <= 0 || value > 100)) {
      return NextResponse.json({ error: 'Percentage must be between 1 and 100' }, { status: 400 })
    }

    const db = supabaseAdmin()
    const { data, error } = await db
      .from('coupons')
      .insert({
        code: code.trim().toUpperCase(),
        type,
        value: parseFloat(value),
        min_order: min_order ? parseFloat(min_order) : 0,
        usage_limit: usage_limit ? parseInt(usage_limit) : null,
        expires_at: expires_at || null,
        is_active: is_active ?? true,
      })
      .select()
      .single()

    if (error) {
      if (error.code === '23505') {
        return NextResponse.json({ error: 'A coupon with this code already exists' }, { status: 409 })
      }
      throw error
    }

    return NextResponse.json(data)
  } catch (err) {
    console.error('Create coupon error:', err)
    return NextResponse.json({ error: 'Failed to create coupon' }, { status: 500 })
  }
}

// PATCH — toggle active or update
export async function PATCH(req: NextRequest) {
  if (!isAdminAuthed(req)) return unauthorized()

  try {
    const body = await req.json()
    const { id, ...updates } = body
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 })

    const db = supabaseAdmin()
    const { data, error } = await db
      .from('coupons')
      .update(updates)
      .eq('id', id)
      .select()
      .single()

    if (error) throw error
    return NextResponse.json(data)
  } catch (err) {
    console.error('Update coupon error:', err)
    return NextResponse.json({ error: 'Failed to update coupon' }, { status: 500 })
  }
}

// DELETE — remove coupon
export async function DELETE(req: NextRequest) {
  if (!isAdminAuthed(req)) return unauthorized()

  const { searchParams } = new URL(req.url)
  const id = searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 })

  const db = supabaseAdmin()
  const { error } = await db.from('coupons').delete().eq('id', id)
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  return NextResponse.json({ ok: true })
}
